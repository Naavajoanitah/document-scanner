import React, { useState } from 'react';
import { Save, Plus, Trash2, Bell, Shield, Database } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';

const Settings = () => {
  const [categories, setCategories] = useState([
    'Legal', 'Finance', 'HR', 'Operations', 'Marketing'
  ]);
  const [newCategory, setNewCategory] = useState('');
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    uploadAlerts: true,
    reviewReminders: false,
    weeklyReports: true,
  });
  const { toast } = useToast();

  const addCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      setCategories([...categories, newCategory.trim()]);
      setNewCategory('');
      toast({
        title: "Category Added",
        description: `${newCategory.trim()} has been added to the categories.`,
      });
    }
  };

  const removeCategory = (categoryToRemove: string) => {
    setCategories(categories.filter(cat => cat !== categoryToRemove));
    toast({
      title: "Category Removed",
      description: `${categoryToRemove} has been removed from the categories.`,
    });
  };

  const saveSettings = () => {
    toast({
      title: "Settings Saved",
      description: "Your settings have been updated successfully.",
    });
  };

  const userRoles = [
    { name: 'Admin', permissions: ['Full Access', 'User Management', 'System Configuration'], count: 2 },
    { name: 'Reviewer', permissions: ['Review Documents', 'Approve/Reject', 'View Reports'], count: 3 },
    { name: 'Uploader', permissions: ['Upload Documents', 'View Own Documents'], count: 8 },
  ];

  return (
    <div className="space-y-6 px-4 sm:px-0">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="text-gray-600 mt-1">Manage your system configuration</p>
      </div>

      <Tabs defaultValue="categories" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="roles">User Roles</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
        </TabsList>

        {/* Categories Tab */}
        <TabsContent value="categories" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Database className="h-5 w-5 mr-2" />
                Document Categories
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex space-x-2">
                <Input
                  placeholder="Add new category"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addCategory()}
                />
                <Button onClick={addCategory}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add
                </Button>
              </div>

              <div className="space-y-2">
                <h4 className="font-medium text-gray-900">Current Categories</h4>
                <div className="flex flex-wrap gap-2">
                  {categories.map((category) => (
                    <div key={category} className="flex items-center bg-gray-100 rounded-full px-3 py-1">
                      <Badge variant="outline" className="mr-2">{category}</Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeCategory(category)}
                        className="h-6 w-6 p-0 hover:bg-destructive hover:text-white"
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Roles Tab */}
        <TabsContent value="roles" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                User Roles & Permissions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {userRoles.map((role) => (
                <div key={role.name} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold text-gray-900">{role.name}</h3>
                    <Badge>{role.count} users</Badge>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">Permissions:</p>
                    <div className="flex flex-wrap gap-2">
                      {role.permissions.map((permission) => (
                        <Badge key={permission} variant="outline">
                          {permission}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="mt-3">
                    Edit Role
                  </Button>
                </div>
              ))}
              
              <Button className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Create New Role
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications Tab */}
        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="h-5 w-5 mr-2" />
                Notification Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="email-notifications" className="text-base font-medium">
                      Email Notifications
                    </Label>
                    <p className="text-sm text-gray-600">Receive email alerts for important events</p>
                  </div>
                  <Switch
                    id="email-notifications"
                    checked={notifications.emailNotifications}
                    onCheckedChange={(checked) => 
                      setNotifications({...notifications, emailNotifications: checked})
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="upload-alerts" className="text-base font-medium">
                      Upload Alerts
                    </Label>
                    <p className="text-sm text-gray-600">Get notified when new documents are uploaded</p>
                  </div>
                  <Switch
                    id="upload-alerts"
                    checked={notifications.uploadAlerts}
                    onCheckedChange={(checked) => 
                      setNotifications({...notifications, uploadAlerts: checked})
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="review-reminders" className="text-base font-medium">
                      Review Reminders
                    </Label>
                    <p className="text-sm text-gray-600">Reminders for pending document reviews</p>
                  </div>
                  <Switch
                    id="review-reminders"
                    checked={notifications.reviewReminders}
                    onCheckedChange={(checked) => 
                      setNotifications({...notifications, reviewReminders: checked})
                    }
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="weekly-reports" className="text-base font-medium">
                      Weekly Reports
                    </Label>
                    <p className="text-sm text-gray-600">Receive weekly summary reports via email</p>
                  </div>
                  <Switch
                    id="weekly-reports"
                    checked={notifications.weeklyReports}
                    onCheckedChange={(checked) => 
                      setNotifications({...notifications, weeklyReports: checked})
                    }
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Tab */}
        <TabsContent value="system" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>System Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="max-file-size">Maximum File Size (MB)</Label>
                  <Input id="max-file-size" type="number" defaultValue="10" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="auto-delete">Auto-delete after (days)</Label>
                  <Input id="auto-delete" type="number" defaultValue="365" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="review-deadline">Review Deadline (days)</Label>
                  <Input id="review-deadline" type="number" defaultValue="7" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="backup-frequency">Backup Frequency</Label>
                  <Input id="backup-frequency" defaultValue="Daily" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-green-50 rounded-lg p-4 text-center">
                  <div className="w-3 h-3 bg-success rounded-full mx-auto mb-2" />
                  <p className="text-sm font-medium">Database</p>
                  <p className="text-xs text-gray-600">Online</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4 text-center">
                  <div className="w-3 h-3 bg-success rounded-full mx-auto mb-2" />
                  <p className="text-sm font-medium">File Storage</p>
                  <p className="text-xs text-gray-600">85% Used</p>
                </div>
                <div className="bg-green-50 rounded-lg p-4 text-center">
                  <div className="w-3 h-3 bg-success rounded-full mx-auto mb-2" />
                  <p className="text-sm font-medium">Email Service</p>
                  <p className="text-xs text-gray-600">Active</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Save Button */}
      <div className="flex justify-end">
        <Button onClick={saveSettings} className="px-8">
          <Save className="h-4 w-4 mr-2" />
          Save All Settings
        </Button>
      </div>
    </div>
  );
};

export default Settings;
