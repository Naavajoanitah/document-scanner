
import React from 'react';
import { Outlet } from 'react-router-dom';
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { AppSidebar } from './AppSidebar';

const Layout = () => {
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <AppSidebar />
        <SidebarInset className="flex-1">
          <header className="sticky top-0 z-40 border-b border-white/20 bg-white/10 backdrop-blur-xl">
            <div className="flex h-16 items-center gap-4 px-6">
              <SidebarTrigger className="glass p-2 rounded-lg hover:bg-white/20 transition-all duration-300" />
              <div className="flex-1">
                <h1 className="text-xl font-bold gradient-text">
                  Gulu District Government
                </h1>
                <p className="text-sm text-gray-600">
                  Document Management System
                </p>
              </div>
              <div className="text-right text-sm text-gray-600">
                {new Date().toLocaleDateString('en-UG', { 
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            </div>
          </header>
          
          <main className="flex-1 overflow-auto">
            <div className="container mx-auto p-6 max-w-7xl animate-fade-in">
              <Outlet />
            </div>
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
};

export default Layout;
