
import React, { useState } from 'react';
import { Download, Calendar, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';

const Reports = () => {
  const [reportPeriod, setReportPeriod] = useState('monthly');

  // Mock data
  const monthlyTrends = [
    { month: 'Jan', uploads: 120, reviews: 115, approvals: 110 },
    { month: 'Feb', uploads: 150, reviews: 145, approvals: 140 },
    { month: 'Mar', uploads: 180, reviews: 175, approvals: 165 },
    { month: 'Apr', uploads: 220, reviews: 210, approvals: 200 },
    { month: 'May', uploads: 250, reviews: 240, approvals: 230 },
    { month: 'Jun', uploads: 280, reviews: 270, approvals: 260 },
  ];

  const topUploaders = [
    { name: 'Mike Johnson', uploads: 78, department: 'Operations' },
    { name: 'Emily Davis', uploads: 56, department: 'HR' },
    { name: 'John Doe', uploads: 45, department: 'Finance' },
    { name: 'Sarah Smith', uploads: 32, department: 'Legal' },
    { name: 'Alex Wilson', uploads: 23, department: 'Marketing' },
  ];

  const categoryMetrics = [
    { category: 'Legal', total: 2100, approved: 1950, pending: 100, rejected: 50 },
    { category: 'Finance', total: 1200, approved: 1100, pending: 80, rejected: 20 },
    { category: 'HR', total: 800, approved: 750, pending: 40, rejected: 10 },
    { category: 'Operations', total: 1020, approved: 950, pending: 50, rejected: 20 },
  ];

  const exportOptions = [
    { label: 'Export as PDF', format: 'pdf' },
    { label: 'Export as CSV', format: 'csv' },
    { label: 'Export as Excel', format: 'xlsx' },
  ];

  return (
    <div className="space-y-6 px-4 sm:px-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reports</h1>
          <p className="text-gray-600 mt-1">Detailed analytics and insights</p>
        </div>
        <div className="flex space-x-2 mt-4 sm:mt-0">
          <Select value={reportPeriod} onValueChange={setReportPeriod}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="monthly">Monthly</SelectItem>
              <SelectItem value="quarterly">Quarterly</SelectItem>
              <SelectItem value="yearly">Yearly</SelectItem>
            </SelectContent>
          </Select>
          <Button>
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Metrics Bento Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Processing Rate</p>
                <p className="text-3xl font-bold text-gray-900">94.7%</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-success" />
                  <span className="text-sm text-success ml-1">+2.3%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Review Time</p>
                <p className="text-3xl font-bold text-gray-900">2.4</p>
                <p className="text-sm text-gray-600">days</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">User Satisfaction</p>
                <p className="text-3xl font-bold text-gray-900">4.8</p>
                <p className="text-sm text-gray-600">out of 5</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Error Rate</p>
                <p className="text-3xl font-bold text-gray-900">1.2%</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-destructive rotate-180" />
                  <span className="text-sm text-success ml-1">-0.5%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Line Chart */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Document Activity Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Line type="monotone" dataKey="uploads" stroke="#4F46E5" strokeWidth={2} />
                <Line type="monotone" dataKey="reviews" stroke="#22C55E" strokeWidth={2} />
                <Line type="monotone" dataKey="approvals" stroke="#3B82F6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex justify-center space-x-6 mt-4">
              <div className="flex items-center">
                <div className="w-3 h-3 bg-primary rounded-full mr-2" />
                <span className="text-sm text-gray-600">Uploads</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-success rounded-full mr-2" />
                <span className="text-sm text-gray-600">Reviews</span>
              </div>
              <div className="flex items-center">
                <div className="w-3 h-3 bg-info rounded-full mr-2" />
                <span className="text-sm text-gray-600">Approvals</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Area Chart */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Review Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={monthlyTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Area type="monotone" dataKey="reviews" stackId="1" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.6} />
                <Area type="monotone" dataKey="approvals" stackId="1" stroke="#22C55E" fill="#22C55E" fillOpacity={0.6} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Tables Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Uploaders */}
        <Card>
          <CardHeader>
            <CardTitle>Top Uploaders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topUploaders.map((uploader, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center text-sm font-medium mr-3">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{uploader.name}</p>
                      <p className="text-sm text-gray-600">{uploader.department}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{uploader.uploads}</p>
                    <p className="text-sm text-gray-600">uploads</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Category Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Category Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {categoryMetrics.map((category, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-900">{category.category}</span>
                    <span className="text-sm text-gray-600">{category.total} total</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-success h-2 rounded-full" 
                      style={{ 
                        width: `${(category.approved / category.total) * 100}%` 
                      }}
                    />
                  </div>
                  <div className="flex justify-between text-xs text-gray-600">
                    <span>{category.approved} approved</span>
                    <span>{category.pending} pending</span>
                    <span>{category.rejected} rejected</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle>Export Options</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {exportOptions.map((option, index) => (
              <Button key={index} variant="outline" className="w-full">
                <Download className="h-4 w-4 mr-2" />
                {option.label}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Reports;
