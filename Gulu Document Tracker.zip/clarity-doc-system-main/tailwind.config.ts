
import type { Config } from "tailwindcss";

export default {
	darkMode: ["class"],
	content: [
		"./pages/**/*.{ts,tsx}",
		"./components/**/*.{ts,tsx}",
		"./app/**/*.{ts,tsx}",
		"./src/**/*.{ts,tsx}",
	],
	prefix: "",
	theme: {
		container: {
			center: true,
			padding: '2rem',
			screens: {
				'2xl': '1400px'
			}
		},
		extend: {
			fontFamily: {
				'sans': ['Inter', 'system-ui', 'sans-serif'],
			},
			colors: {
				border: 'hsl(var(--border))',
				input: 'hsl(var(--input))',
				ring: 'hsl(var(--ring))',
				background: 'hsl(var(--background))',
				foreground: 'hsl(var(--foreground))',
				primary: {
					DEFAULT: '#1f306e',
					50: '#f0f4ff',
					100: '#e6ecff',
					200: '#d0dfff',
					300: '#aac5ff',
					400: '#7ba0ff',
					500: '#4f79ff',
					600: '#2b56f5',
					700: '#1d3fe1',
					800: '#1e35b6',
					900: '#1f306e',
					foreground: '#FFFFFF'
				},
				secondary: {
					DEFAULT: '#553772',
					50: '#faf7fc',
					100: '#f3eef8',
					200: '#e8def1',
					300: '#d7c3e6',
					400: '#c09bd7',
					500: '#a674c4',
					600: '#8d55ab',
					700: '#75448f',
					800: '#553772',
					900: '#4a315f',
					foreground: '#FFFFFF'
				},
				accent: {
					DEFAULT: '#8f3b76',
					50: '#fdf4f8',
					100: '#fce7f0',
					200: '#fad1e3',
					300: '#f5aace',
					400: '#ed75ab',
					500: '#e1478b',
					600: '#cf2a6d',
					700: '#b01d55',
					800: '#8f3b76',
					900: '#7a1c4a',
					foreground: '#FFFFFF'
				},
				destructive: {
					DEFAULT: '#c7417b',
					50: '#fdf4f7',
					100: '#fce8f1',
					200: '#fad2e4',
					300: '#f5aecf',
					400: '#ed7db0',
					500: '#e04d92',
					600: '#c7417b',
					700: '#b22760',
					800: '#951f4f',
					900: '#7e1b44',
					foreground: '#FFFFFF'
				},
				success: {
					DEFAULT: '#f5487f',
					50: '#fef4f6',
					100: '#fde8ef',
					200: '#fcd2e2',
					300: '#f9aeca',
					400: '#f47ea8',
					500: '#f5487f',
					600: '#e92d6a',
					700: '#d41355',
					800: '#b11349',
					900: '#951242',
					foreground: '#FFFFFF'
				},
				muted: {
					DEFAULT: 'hsl(var(--muted))',
					foreground: 'hsl(var(--muted-foreground))'
				},
				popover: {
					DEFAULT: 'hsl(var(--popover))',
					foreground: 'hsl(var(--popover-foreground))'
				},
				card: {
					DEFAULT: 'hsl(var(--card))',
					foreground: 'hsl(var(--card-foreground))'
				},
				sidebar: {
					DEFAULT: 'hsl(var(--sidebar-background))',
					foreground: 'hsl(var(--sidebar-foreground))',
					primary: 'hsl(var(--sidebar-primary))',
					'primary-foreground': 'hsl(var(--sidebar-primary-foreground))',
					accent: 'hsl(var(--sidebar-accent))',
					'accent-foreground': 'hsl(var(--sidebar-accent-foreground))',
					border: 'hsl(var(--sidebar-border))',
					ring: 'hsl(var(--sidebar-ring))'
				}
			},
			borderRadius: {
				lg: 'var(--radius)',
				md: 'calc(var(--radius) - 2px)',
				sm: 'calc(var(--radius) - 4px)'
			},
			keyframes: {
				'accordion-down': {
					from: {
						height: '0'
					},
					to: {
						height: 'var(--radix-accordion-content-height)'
					}
				},
				'accordion-up': {
					from: {
						height: 'var(--radix-accordion-content-height)'
					},
					to: {
						height: '0'
					}
				},
				'fade-in': {
					'0%': {
						opacity: '0',
						transform: 'translateY(10px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateY(0)'
					}
				},
				'slide-in': {
					'0%': {
						opacity: '0',
						transform: 'translateX(-20px)'
					},
					'100%': {
						opacity: '1',
						transform: 'translateX(0)'
					}
				}
			},
			animation: {
				'accordion-down': 'accordion-down 0.2s ease-out',
				'accordion-up': 'accordion-up 0.2s ease-out',
				'fade-in': 'fade-in 0.3s ease-out',
				'slide-in': 'slide-in 0.3s ease-out'
			},
			backdropBlur: {
				xs: '2px',
			},
			backgroundImage: {
				'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
				'gradient-mesh': 'radial-gradient(at 40% 20%, hsla(228,74%,100%,1) 0px, transparent 50%), radial-gradient(at 80% 0%, hsla(189,100%,80%,1) 0px, transparent 50%), radial-gradient(at 0% 50%, hsla(355,100%,93%,1) 0px, transparent 50%)',
			}
		}
	},
	plugins: [require("tailwindcss-animate")],
} satisfies Config;
