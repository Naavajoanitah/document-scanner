
import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  FileText, 
  BarChart3, 
  Upload, 
  Users, 
  FileBarChart, 
  Settings,
  Building2,
  MapPin
} from 'lucide-react';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

const navItems = [
  { to: "/", icon: BarChart3, label: "Dashboard" },
  { to: "/documents", icon: FileText, label: "Documents" },
  { to: "/upload", icon: Upload, label: "Upload" },
  { to: "/users", icon: Users, label: "Users" },
  { to: "/reports", icon: FileBarChart, label: "Reports" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

export function AppSidebar() {
  return (
    <Sidebar className="border-r-0 shadow-2xl">
      <SidebarHeader className="border-b border-white/10 bg-gradient-to-br from-primary-600 to-primary-900">
        <div className="flex items-center gap-3 p-4">
          <div className="p-2 rounded-xl bg-white/20 backdrop-blur-sm">
            <Building2 className="h-8 w-8 text-white" />
          </div>
          <div className="text-white">
            <h2 className="text-lg font-bold tracking-tight">Gulu District</h2>
            <p className="text-xs text-white/80 flex items-center gap-1">
              <MapPin className="h-3 w-3" />
              Document Tracker
            </p>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="bg-gradient-to-b from-primary-600 to-primary-800">
        <SidebarGroup>
          <SidebarGroupLabel className="text-white/70 text-xs font-medium uppercase tracking-wider px-4 py-2">
            Navigation
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="gap-2 px-2">
              {navItems.map(({ to, icon: Icon, label }) => (
                <SidebarMenuItem key={to}>
                  <SidebarMenuButton asChild className="group">
                    <NavLink
                      to={to}
                      className={({ isActive }) =>
                        `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                          isActive
                            ? 'bg-white/20 text-white shadow-lg backdrop-blur-sm border border-white/30'
                            : 'text-white/80 hover:text-white hover:bg-white/10'
                        }`
                      }
                    >
                      <Icon className="h-5 w-5 transition-transform group-hover:scale-110" />
                      <span className="font-medium">{label}</span>
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter className="border-t border-white/10 bg-gradient-to-br from-primary-700 to-primary-900 p-4">
        <div className="text-center">
          <p className="text-xs text-white/60">
            Powered by
          </p>
          <p className="text-sm font-semibold text-white">
            Joan Technologies
          </p>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
