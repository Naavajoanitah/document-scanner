import React, { useState } from 'react';
import { 
  FileText, 
  CheckCircle, 
  Clock, 
  Users, 
  TrendingUp, 
  TrendingDown 
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import GululMap from '../components/GululMap';

const Dashboard = () => {
  const [selectedPeriod, setSelectedPeriod] = useState('month');

  // Mock data
  const monthlyData = [
    { month: 'Jan', uploads: 400, approvals: 380 },
    { month: 'Feb', uploads: 300, approvals: 290 },
    { month: 'Mar', uploads: 500, approvals: 480 },
    { month: 'Apr', uploads: 650, approvals: 620 },
    { month: 'May', uploads: 720, approvals: 700 },
    { month: 'Jun', uploads: 820, approvals: 800 },
  ];

  const categoryData = [
    { name: 'Legal', value: 2100, color: '#4F46E5' },
    { name: 'Finance', value: 1200, color: '#22C55E' },
    { name: 'HR', value: 800, color: '#3B82F6' },
    { name: 'Operations', value: 1020, color: '#EF4444' },
  ];

  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  return (
    <div className="space-y-6 px-4 sm:px-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Document Tracker</h1>
          <p className="text-gray-600 mt-1">{formattedDate}</p>
        </div>
      </div>

      {/* Bento Grid Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-none shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Documents</p>
                <p className="text-3xl font-bold text-gray-900">5,120</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-success" />
                  <span className="text-sm text-success ml-1">+12.5%</span>
                </div>
              </div>
              <FileText className="h-12 w-12 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-none shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Processed</p>
                <p className="text-3xl font-bold text-gray-900">4,850</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-success" />
                  <span className="text-sm text-success ml-1">+8.2%</span>
                </div>
              </div>
              <CheckCircle className="h-12 w-12 text-success opacity-70" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-none shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Pending Reviews</p>
                <p className="text-3xl font-bold text-gray-900">270</p>
                <div className="flex items-center mt-2">
                  <TrendingDown className="h-4 w-4 text-destructive" />
                  <span className="text-sm text-destructive ml-1">-3.1%</span>
                </div>
              </div>
              <Clock className="h-12 w-12 text-destructive opacity-70" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-none shadow-md hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Unique Uploaders</p>
                <p className="text-3xl font-bold text-gray-900">1,240</p>
                <div className="flex items-center mt-2">
                  <TrendingUp className="h-4 w-4 text-success" />
                  <span className="text-sm text-success ml-1">+15.3%</span>
                </div>
              </div>
              <Users className="h-12 w-12 text-primary opacity-70" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Bar Chart */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Document Activity
              <Tabs value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="month">This Month</TabsTrigger>
                  <TabsTrigger value="year">This Year</TabsTrigger>
                </TabsList>
              </Tabs>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Bar dataKey="uploads" fill="#4F46E5" name="Uploads" />
                <Bar dataKey="approvals" fill="#22C55E" name="Approvals" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pie Chart */}
        <Card className="shadow-md">
          <CardHeader>
            <CardTitle>Document Categories</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={categoryData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-4 mt-4">
              {categoryData.map((category) => (
                <div key={category.name} className="flex items-center">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ backgroundColor: category.color }}
                  />
                  <span className="text-sm text-gray-600">
                    {category.name}: {category.value.toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Gulu City Upload Locations Map */}
      <Card className="shadow-md">
        <CardHeader>
          <CardTitle>Upload Locations - Gulu City</CardTitle>
        </CardHeader>
        <CardContent>
          <GululMap />
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
