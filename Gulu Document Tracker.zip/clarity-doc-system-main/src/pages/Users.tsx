import React, { useState } from 'react';
import { Search, UserPlus, MoreHorizontal, Mail, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Users = () => {
  const [searchTerm, setSearchTerm] = useState('');

  // Mock data with Ugandan names
  const users = [
    {
      id: 1,
      name: 'Ocan Alfred',
      email: 'ocan.alfred@gulu.go.ug',
      role: 'Admin',
      documentsCount: 45,
      approvalsCount: 120,
      joinDate: '2023-01-15',
      status: 'active'
    },
    {
      id: 2,
      name: 'Acheng Lilian',
      email: 'acheng.lilian@gulu.go.ug',
      role: 'Reviewer',
      documentsCount: 32,
      approvalsCount: 89,
      joinDate: '2023-03-20',
      status: 'active'
    },
    {
      id: 3,
      name: 'Apio Sarah Gladys',
      email: 'apio.sarah@gulu.go.ug',
      role: 'Uploader',
      documentsCount: 78,
      approvalsCount: 0,
      joinDate: '2023-05-10',
      status: 'active'
    },
    {
      id: 4,
      name: 'Rwothmio Trevor',
      email: 'rwothmio.trevor@gulu.go.ug',
      role: 'Uploader',
      documentsCount: 56,
      approvalsCount: 0,
      joinDate: '2023-07-08',
      status: 'inactive'
    },
    {
      id: 5,
      name: 'Otim Conrad',
      email: 'otim.conrad@gulu.go.ug',
      role: 'Reviewer',
      documentsCount: 23,
      approvalsCount: 67,
      joinDate: '2023-09-12',
      status: 'active'
    },
  ];

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'Admin':
        return <Badge className="bg-primary text-white">Admin</Badge>;
      case 'Reviewer':
        return <Badge className="bg-info text-white">Reviewer</Badge>;
      case 'Uploader':
        return <Badge className="bg-success text-white">Uploader</Badge>;
      default:
        return <Badge variant="secondary">{role}</Badge>;
    }
  };

  const getStatusBadge = (status: string) => {
    return status === 'active' ? (
      <Badge className="bg-success text-white">Active</Badge>
    ) : (
      <Badge className="bg-gray-500 text-white">Inactive</Badge>
    );
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const filteredUsers = users.filter(user =>
    user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.role.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const roleStats = {
    admin: users.filter(u => u.role === 'Admin').length,
    reviewer: users.filter(u => u.role === 'Reviewer').length,
    uploader: users.filter(u => u.role === 'Uploader').length,
  };

  return (
    <div className="space-y-6 px-4 sm:px-0">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Users</h1>
        <Button className="mt-4 sm:mt-0">
          <UserPlus className="h-4 w-4 mr-2" />
          Add User
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-600">Total Users</p>
              <p className="text-3xl font-bold text-gray-900">{users.length}</p>
              <p className="text-sm text-gray-500 mt-1">All registered users</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-600">Active Users</p>
              <p className="text-3xl font-bold text-gray-900">
                {users.filter(u => u.status === 'active').length}
              </p>
              <p className="text-sm text-gray-500 mt-1">Currently active</p>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-none shadow-md">
          <CardContent className="p-6">
            <div className="text-center">
              <p className="text-sm font-medium text-gray-600">Total Uploads</p>
              <p className="text-3xl font-bold text-gray-900">
                {users.reduce((sum, user) => sum + user.documentsCount, 0)}
              </p>
              <p className="text-sm text-gray-500 mt-1">Documents uploaded</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Role Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>Role Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-primary/10 rounded-lg p-4 text-center">
              <p className="text-2xl font-bold text-primary">{roleStats.admin}</p>
              <p className="text-sm text-gray-600">Administrators</p>
            </div>
            <div className="bg-info/10 rounded-lg p-4 text-center">
              <p className="text-2xl font-bold text-info">{roleStats.reviewer}</p>
              <p className="text-sm text-gray-600">Reviewers</p>
            </div>
            <div className="bg-success/10 rounded-lg p-4 text-center">
              <p className="text-2xl font-bold text-success">{roleStats.uploader}</p>
              <p className="text-sm text-gray-600">Uploaders</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search users by name, email, or role..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Users List */}
      <Card>
        <CardHeader>
          <CardTitle>All Users ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredUsers.map((user) => (
              <div key={user.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarFallback className="bg-primary text-white">
                      {getInitials(user.name)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-gray-900">{user.name}</h3>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <Mail className="h-3 w-3 mr-1" />
                      {user.email}
                    </div>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <Calendar className="h-3 w-3 mr-1" />
                      Joined {new Date(user.joinDate).toLocaleDateString()}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm font-medium text-gray-900">{user.documentsCount} uploads</p>
                    {user.role === 'Reviewer' || user.role === 'Admin' ? (
                      <p className="text-sm text-gray-600">{user.approvalsCount} approvals</p>
                    ) : null}
                  </div>
                  
                  <div className="flex flex-col space-y-1">
                    {getRoleBadge(user.role)}
                    {getStatusBadge(user.status)}
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>Edit User</DropdownMenuItem>
                      <DropdownMenuItem>View Activity</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive">
                        {user.status === 'active' ? 'Deactivate' : 'Activate'}
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Users;
