
import React, { useState } from 'react';
import { Upload as UploadIcon, FileText, Image, File, CheckCircle2, AlertCircle, Cloud } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Upload = () => {
  const [dragActive, setDragActive] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [uploadProgress, setUploadProgress] = useState(0);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const handleFiles = (files: FileList) => {
    setUploadStatus('uploading');
    setUploadProgress(0);
    
    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadStatus('success');
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split('.').pop()?.toLowerCase();
    switch (extension) {
      case 'pdf':
        return <FileText className="h-8 w-8 text-red-500" />;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return <Image className="h-8 w-8 text-blue-500" />;
      default:
        return <File className="h-8 w-8 text-gray-500" />;
    }
  };

  const recentUploads = [
    { name: 'Budget Report 2024.pdf', date: '2 hours ago', size: '2.4 MB', status: 'approved' },
    { name: 'Development Plan.docx', date: '5 hours ago', size: '1.8 MB', status: 'pending' },
    { name: 'District Map.png', date: '1 day ago', size: '5.2 MB', status: 'approved' },
    { name: 'Census Data.xlsx', date: '2 days ago', size: '3.1 MB', status: 'rejected' },
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="bento-card">
        <div className="flex items-center gap-4 mb-6">
          <div className="p-3 rounded-2xl bg-gradient-to-br from-primary-500 to-secondary-500">
            <Cloud className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold gradient-text">Document Upload</h1>
            <p className="text-gray-600 mt-1">Upload and manage your district documents securely</p>
          </div>
        </div>
      </div>

      {/* Bento Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Main Upload Area - Takes 2 columns */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Upload Zone */}
          <div className="bento-card">
            <div
              className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-300 ${
                dragActive 
                  ? 'border-primary-400 bg-primary-50/50 scale-105' 
                  : 'border-gray-300 hover:border-primary-300 hover:bg-primary-50/30'
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
            >
              <input
                type="file"
                multiple
                onChange={handleChange}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="p-4 rounded-full bg-gradient-to-br from-primary-100 to-secondary-100">
                    <UploadIcon className="h-12 w-12 text-primary-600" />
                  </div>
                </div>
                
                <div>
                  <h3 className="text-xl font-semibold text-gray-800 mb-2">
                    Drop your files here, or browse
                  </h3>
                  <p className="text-gray-500">
                    Supports PDF, DOC, DOCX, XLS, XLSX, PNG, JPG up to 10MB
                  </p>
                </div>
                
                <Button className="morphism-button bg-gradient-to-r from-primary-500 to-secondary-500 text-white border-0 hover:from-primary-600 hover:to-secondary-600">
                  Select Files
                </Button>
              </div>
            </div>

            {/* Upload Progress */}
            {uploadStatus === 'uploading' && (
              <div className="mt-6 p-4 glass rounded-xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-2 border-primary-500 border-t-transparent"></div>
                  <span className="font-medium">Uploading... {uploadProgress}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div 
                    className="bg-gradient-to-r from-primary-500 to-secondary-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${uploadProgress}%` }}
                  ></div>
                </div>
              </div>
            )}

            {/* Success Message */}
            {uploadStatus === 'success' && (
              <div className="mt-6 p-4 glass rounded-xl border border-green-200 bg-green-50/50">
                <div className="flex items-center gap-3 text-green-700">
                  <CheckCircle2 className="h-5 w-5" />
                  <span className="font-medium">Upload completed successfully!</span>
                </div>
              </div>
            )}
          </div>

          {/* Document Details Form */}
          <div className="bento-card">
            <h3 className="text-lg font-semibold mb-4 gradient-text">Document Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Document Title</label>
                <input 
                  type="text" 
                  className="glass w-full px-4 py-2 rounded-lg border border-white/30 focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  placeholder="Enter document title"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select className="glass w-full px-4 py-2 rounded-lg border border-white/30 focus:ring-2 focus:ring-primary-500 focus:border-transparent">
                  <option>Select category</option>
                  <option>Administrative</option>
                  <option>Financial</option>
                  <option>Legal</option>
                  <option>Development</option>
                  <option>Health</option>
                  <option>Education</option>
                </select>
              </div>
              
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea 
                  className="glass w-full px-4 py-2 rounded-lg border border-white/30 focus:ring-2 focus:ring-primary-500 focus:border-transparent h-20"
                  placeholder="Brief description of the document"
                ></textarea>
              </div>
            </div>
            
            <div className="flex gap-3 mt-6">
              <Button className="morphism-button bg-gradient-to-r from-primary-500 to-secondary-500 text-white border-0 hover:from-primary-600 hover:to-secondary-600">
                Submit Document
              </Button>
              <Button variant="outline" className="glass border-white/30 hover:bg-white/20">
                Save as Draft
              </Button>
            </div>
          </div>
        </div>

        {/* Sidebar - Statistics and Recent Uploads */}
        <div className="space-y-6">
          
          {/* Upload Statistics */}
          <div className="bento-card">
            <h3 className="text-lg font-semibold mb-4 gradient-text">Upload Statistics</h3>
            <div className="space-y-4">
              <div className="flex justify-between items-center p-3 glass rounded-lg">
                <span className="text-sm text-gray-600">Today</span>
                <span className="font-semibold text-primary-600">12 files</span>
              </div>
              <div className="flex justify-between items-center p-3 glass rounded-lg">
                <span className="text-sm text-gray-600">This Week</span>
                <span className="font-semibold text-secondary-600">45 files</span>
              </div>
              <div className="flex justify-between items-center p-3 glass rounded-lg">
                <span className="text-sm text-gray-600">This Month</span>
                <span className="font-semibold text-accent-600">189 files</span>
              </div>
              <div className="flex justify-between items-center p-3 glass rounded-lg">
                <span className="text-sm text-gray-600">Storage Used</span>
                <span className="font-semibold text-destructive-600">2.4 GB</span>
              </div>
            </div>
          </div>

          {/* Recent Uploads */}
          <div className="bento-card">
            <h3 className="text-lg font-semibold mb-4 gradient-text">Recent Uploads</h3>
            <div className="space-y-3">
              {recentUploads.map((file, index) => (
                <div key={index} className="p-3 glass rounded-lg hover:bg-white/30 transition-all duration-300">
                  <div className="flex items-start gap-3">
                    {getFileIcon(file.name)}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-800 truncate">{file.name}</p>
                      <p className="text-xs text-gray-500">{file.date} • {file.size}</p>
                      <div className="flex items-center gap-1 mt-1">
                        {file.status === 'approved' && (
                          <>
                            <CheckCircle2 className="h-3 w-3 text-green-500" />
                            <span className="text-xs text-green-600">Approved</span>
                          </>
                        )}
                        {file.status === 'pending' && (
                          <>
                            <AlertCircle className="h-3 w-3 text-yellow-500" />
                            <span className="text-xs text-yellow-600">Pending</span>
                          </>
                        )}
                        {file.status === 'rejected' && (
                          <>
                            <AlertCircle className="h-3 w-3 text-red-500" />
                            <span className="text-xs text-red-600">Rejected</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Upload;
