
import React, { useEffect, useRef } from 'react';
import { MapPin } from 'lucide-react';

const GululMap = () => {
  const mapRef = useRef<HTMLDivElement>(null);

  const uploadLocations = [
    { id: 1, name: 'District Headquarters', coords: { lat: 2.7769, lng: 32.2996 }, uploads: 45, color: '#1F306E' },
    { id: 2, name: 'Municipal Council', coords: { lat: 2.7829, lng: 32.3056 }, uploads: 32, color: '#553772' },
    { id: 3, name: 'Health Center IV', coords: { lat: 2.7709, lng: 32.2936 }, uploads: 28, color: '#8F3B76' },
    { id: 4, name: 'Gulu University', coords: { lat: 2.7889, lng: 32.3116 }, uploads: 23, color: '#C7417B' },
    { id: 5, name: 'Central Market', coords: { lat: 2.7749, lng: 32.3016 }, uploads: 18, color: '#F5487F' },
    { id: 6, name: 'District Hospital', coords: { lat: 2.7729, lng: 32.2976 }, uploads: 15, color: '#553772' },
  ];

  return (
    <div className="relative w-full h-80 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg overflow-hidden">
      {/* Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-100 via-indigo-50 to-purple-50">
        {/* Simplified map representation */}
        <svg width="100%" height="100%" viewBox="0 0 400 320" className="absolute inset-0">
          {/* River Aswa representation */}
          <path
            d="M50 200 Q150 180 250 190 Q300 195 350 200"
            stroke="#4A90E2"
            strokeWidth="4"
            fill="none"
            opacity="0.6"
          />
          
          {/* Road network */}
          <path d="M0 160 L400 160" stroke="#64748B" strokeWidth="2" opacity="0.4" />
          <path d="M200 0 L200 320" stroke="#64748B" strokeWidth="2" opacity="0.4" />
          <path d="M100 80 L300 240" stroke="#64748B" strokeWidth="1.5" opacity="0.3" />
          <path d="M300 80 L100 240" stroke="#64748B" strokeWidth="1.5" opacity="0.3" />
        </svg>

        {/* Upload location markers */}
        {uploadLocations.map((location, index) => (
          <div
            key={location.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 animate-pulse"
            style={{
              left: `${20 + index * 12 + Math.sin(index) * 15}%`,
              top: `${30 + index * 8 + Math.cos(index) * 20}%`,
            }}
          >
            <div className="relative group cursor-pointer">
              <div
                className="w-6 h-6 rounded-full border-2 border-white shadow-lg flex items-center justify-center"
                style={{ backgroundColor: location.color }}
              >
                <MapPin className="w-3 h-3 text-white" />
              </div>
              
              {/* Tooltip */}
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                <div className="bg-gray-900 text-white text-xs rounded-lg px-3 py-2 whitespace-nowrap">
                  <div className="font-semibold">{location.name}</div>
                  <div className="text-gray-300">{location.uploads} uploads</div>
                  <div className="absolute top-full left-1/2 transform -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-900"></div>
                </div>
              </div>

              {/* Ripple effect */}
              <div
                className="absolute inset-0 rounded-full animate-ping opacity-30"
                style={{ backgroundColor: location.color }}
              ></div>
            </div>
          </div>
        ))}

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-md">
          <h4 className="text-xs font-semibold text-gray-800 mb-2">Upload Locations</h4>
          <div className="space-y-1">
            {uploadLocations.slice(0, 3).map((location) => (
              <div key={location.id} className="flex items-center space-x-2">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: location.color }}
                ></div>
                <span className="text-xs text-gray-600">{location.name}</span>
              </div>
            ))}
            <div className="text-xs text-gray-500 pt-1">+{uploadLocations.length - 3} more locations</div>
          </div>
        </div>

        {/* North indicator */}
        <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg p-2 shadow-md">
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 flex items-center justify-center">
              <div className="w-0 h-0 border-l-2 border-r-2 border-b-4 border-transparent border-b-gray-800"></div>
            </div>
            <span className="text-xs font-semibold text-gray-800">N</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GululMap;
